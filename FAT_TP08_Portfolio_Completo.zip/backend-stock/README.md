# Sistema de Gestión de Stock

## Descripción

Proyecto académico orientado a la gestión de productos y control de stock. La propuesta utiliza una API backend y una base de datos relacional para organizar la información.

## Objetivos

- Registrar productos.
- Consultar productos.
- Actualizar cantidades disponibles.
- Mantener datos estructurados en una base de datos.
- Separar la lógica backend de la interfaz web.

## Tecnologías propuestas

- Node.js
- Express
- SQLite / SQL
- API REST

## Modelo de datos

La tabla principal es `productos` y contiene:

| Campo | Tipo | Descripción |
|---|---|---|
| id | INTEGER | Identificador único |
| nombre | TEXT | Nombre del producto |
| categoria | TEXT | Categoría |
| precio | REAL | Precio |
| stock | INTEGER | Cantidad disponible |

El archivo `database/schema.sql` contiene el script de creación y datos iniciales.

## Endpoints de referencia

- `GET /api/productos` — listar productos.
- `GET /api/productos/:id` — consultar un producto.
- `POST /api/productos` — crear un producto.
- `PUT /api/productos/:id` — actualizar un producto.
- `DELETE /api/productos/:id` — eliminar un producto.

## Evidencia para el TP08

En un portfolio estático, el proyecto backend se documenta mediante:

1. Descripción del sistema.
2. Tecnologías utilizadas.
3. Modelo de datos.
4. Código fuente / script SQL.
5. Enlace al repositorio.

> Importante: antes de entregar, reemplazá o complementá esta documentación con capturas reales de tu sistema si ya tenés uno realizado en clases.
